﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Api.Models;
using Api.Classes;
using System.Net;
using Newtonsoft.Json;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Api.Controllers
{
    [Route("api/Author")]
    [ApiController]
    public class AuthorController : ControllerBase
    {


        // GET api/<controller>/5
        [HttpGet("{id}", Name = "GetAuthor")]
        [Produces("application/json")]
        public IActionResult GetByID(int id)
        {
            JsonResult Response;
            HttpStatusCode StatusCode = 0;



            Response = Api.Classes.Middleware.GetResponse("https://fakerestapi.azurewebsites.net/api/Authors/" + id.ToString(), "GET", ref StatusCode);

            if (StatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Error:" + StatusCode.ToString());
            }
            return Ok(Response);
        }

        [HttpGet]
        [Produces("application/json")]
        public IActionResult GetAll()
        {
            JsonResult Response;

            HttpStatusCode StatusCode = 0;

            Response = Api.Classes.Middleware.GetResponse("https://fakerestapi.azurewebsites.net/api/Authors/", "GET", ref StatusCode);

            if (StatusCode != HttpStatusCode.OK)
            {
                throw new Exception("Error:" + StatusCode.ToString());
            }


            return Ok(Response);
        }

        [HttpPost]
        public IActionResult Create(Book book)
        {
            JsonResult Response;

            HttpStatusCode StatusCode = 0;

            Response = Api.Classes.Middleware.GetResponse("https://fakerestapi.azurewebsites.net/api/Authors/", "POST", ref StatusCode);


            return null;//CreatedAtRoute("GetTodo", new { id = item.Id }, item);
        }

        [HttpPut("{Id}")]
        public IActionResult Update(Int32 Id, Book book)
        {

            JsonResult Response;

            HttpStatusCode StatusCode = 0;

            Response = Api.Classes.Middleware.GetResponse("https://fakerestapi.azurewebsites.net/api/Authors/1", "PUT", ref StatusCode);

            return NoContent();
        }

        [HttpDelete("{Id}")]
        public IActionResult Delete(Int32 Id)
        {
            JsonResult Response;

            HttpStatusCode StatusCode = 0;

            Response = Api.Classes.Middleware.GetResponse("https://fakerestapi.azurewebsites.net/api/Authors/" + Id.ToString(), "DELETE", ref StatusCode);
            return Ok(Response);
        }

    }
}
