﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using Microsoft.AspNetCore.Mvc.Internal;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;

namespace Api.Classes
{
    public static class Middleware
    {
        public static JsonResult GetResponse(String Url, String Method, ref HttpStatusCode StatusCode)
        {            
            string strResponse;
            WebRequest requestObject = WebRequest.Create(Url);
            requestObject.Method = Method;
            HttpWebResponse responseObject = null;
            responseObject = (HttpWebResponse)requestObject.GetResponse();

            StatusCode = responseObject.StatusCode;

            using (Stream stream = responseObject.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream);
                strResponse = reader.ReadToEnd();
                reader.Close();
            }

            //strResponse = "{data:[" + strResponse + "]}";
            JsonResult json = new JsonResult(strResponse);
            return json;
        }
    }
}
