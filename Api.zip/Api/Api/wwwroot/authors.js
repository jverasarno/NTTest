﻿$(document).ready(function () {
    $("#authorTable").DataTable({
        "processing": true,
        "serverSide": true,
        "filter": true,
        "ajax": {
            "url": "/api/author",
            "type": "GET",
            "datatype": "json"
        },
        "columnDefs": [{
            "targets": [0],
            "visible": false,
            "searchable": false
        }],
        "columns": [
            { "value": "ID", "name": "ID", "autoWidth": true },
            { "value": "IDBook", "name": "IDBook", "autoWidth": true },
            { "value": "FirstName", "name": "First Name", "autoWidth": true },
            { "value": "LastName", "name": "Last Name", "autoWidth": true },
            {
                "render": function (data, row) { return "<a href='#' class='btn btn-danger' onclick=DeleteData('" + row.ID + "'); >Delete</a>"; }
            },
        ]
    });
});


function DeleteData(Id) {
    if (confirm("Are you sure you want to delete ...?")) {
        Delete(Id);
    } else {
        return false;
    }
}


function Delete(Id) {
    var url = '@Url.Content("~/")' + "api/book/" + Id;

    $.post(url, { ID: Id }, function (data) {
        if (data) {
            oTable = $('#bookTable').DataTable();
            oTable.draw();
        } else {
            alert("Something Went Wrong!");
        }
    });
}  