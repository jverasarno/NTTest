﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Models
{
    public class Book
    {
        public Int32 ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string PageCount { get; set; }
        public string Excerpt { get; set; }
        public DateTime PublishDate { get; set; }
    }

}
